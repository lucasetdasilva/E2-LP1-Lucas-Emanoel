/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

/**
 *
 * @author Lucas Emanoel
 */
public class Celular {
    
    private String nome;
    private String marca;
    private float polegada;
    private String ip;
    private String cor;
    private int carga;
    private int foto;
    private int audio;
    private int app;

    public Celular(String nome, String marca, float polegada, String ip, String cor) {
        this.nome = nome;
        this.marca = marca;
        this.polegada = polegada;
        this.ip = ip;
        this.cor = cor;
    }
    
     public Celular(){
         
     }

    public int getAudio() {
        return audio;
    }

    public void setAudio(int audio) {
        this.audio = audio;
    }

    public int getApp() {
        return app;
    }

    public void setApp(int app) {
        this.app = app;
    }
    
    

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public float getPolegada() {
        return polegada;
    }

    public void setPolegada(float polegada) {
        this.polegada = polegada;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }
    
    
    public String carregar(){
        carga = carga + 5;
        if (carga == 100){
            return("A Bateria está cheia" + String.valueOf(carga = carga + 0) + "");
            
        }
        else{
            return(String.valueOf(carga) + "%");
        }
             
    }
    
    public String descarregar(){
        carga = carga - 5;
        
        if (carga == 0 || carga < 0){
            return("A bateria foi zerada");
        }
        else{
            return(String.valueOf(carga) + "%");
        }
    }

    public int getCarga() {
        return carga;
    }

    public void setCarga(int carga) {
        this.carga = carga;
    }
    
    public void tirarFoto(){
        foto = foto + 1;
        
    }
    
    public void escutarAudio(){
        audio = audio + 1;
    }
    
    public void abrirApp(){
        app = app + 1;
        
    }
    
    public String desligar(){
        return("Desligado");
    }
    
    public String ligar(){
        return("Ligado");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
           
        
    }
}
