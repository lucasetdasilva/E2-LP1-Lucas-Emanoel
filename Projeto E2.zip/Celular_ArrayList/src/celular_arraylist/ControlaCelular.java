/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package celular_arraylist;

import DTO.Celular;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 *
 * @author Lucas Emanoel
 */
public class ControlaCelular {
    
    private ArrayList<Celular> celulares = new ArrayList<>();
    private HashSet<String> celulares2 = new HashSet<>();
    private Map<String,String> nome = new HashMap<>();
    private Map<String,String> marca = new HashMap<>();
    private Map<String,String> ip = new HashMap<>();
    private Map<String,Float> polegada = new HashMap<>();
    private Map<String,String> cor = new HashMap<>();
    
    public boolean Map(Celular c){
        
        if (c != null){
            nome.put("Nome", c.getNome());
            marca.put("Marca", c.getMarca());
            ip.put("Ip", c.getIp());
            polegada.put("Polegada", c.getPolegada());
            cor.put("Cor", c.getCor());
                
            return true;
        } else{
            return false;
        }
    }
    
    public Map<String,String> retornaNome(){
        return nome;
    }
    
    public Map<String,String> retornaMarca(){
        return marca;
    }
    
    public Map<String,String> retornaIp(){
        return ip;
    }
    
    public Map<String,Float> retornaPolegada(){
        return polegada;
    }
    
    public Map<String,String> retornaCor(){
        return cor;
    }
    
    public HashSet<String> retornaHashSet(){
        return celulares2;
    }
    
    public boolean salvar(Celular c){
     
        if (c != null){
            celulares.add(c);
            return true;
        } else {
            return false;
        }
    }
    
    public boolean salvarHash(Celular c){
        
        if (c != null){
            celulares2.add(c.getIp());
            return true;
            
        } else{
            return false;
        }
    }
    
    public ArrayList<Celular> retornaCelulares(){
        return celulares;
        
    }
    

}
